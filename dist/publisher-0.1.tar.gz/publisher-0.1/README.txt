Convert an IPython notebook into an HTML file that can be consumed
by GitHub pages in plotly's documentation repo.

