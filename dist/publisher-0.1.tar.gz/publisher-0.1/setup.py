from setuptools import setup


setup(
    name='publisher',
    version='0.1',
    author='chris p',
    author_email='chris@plot.ly',
    packages=['publisher'],
    license='See LICENSE.txt',
    description='',
    long_description=open('README.txt').read(),
    url='https://github.com/plotly/documentation'
)
